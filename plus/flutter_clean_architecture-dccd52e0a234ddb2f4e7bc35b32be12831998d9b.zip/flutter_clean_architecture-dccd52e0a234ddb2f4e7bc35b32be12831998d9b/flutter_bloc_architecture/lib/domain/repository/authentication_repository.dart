abstract class AuthenticationRepository{

}
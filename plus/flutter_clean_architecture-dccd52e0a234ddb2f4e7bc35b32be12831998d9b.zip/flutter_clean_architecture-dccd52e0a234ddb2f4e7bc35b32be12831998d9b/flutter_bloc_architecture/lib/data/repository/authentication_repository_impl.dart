import 'package:flutter_bloc_architecture/domain/repository/authentication_repository.dart';

class AuthenticationRepositoryImpl extends AuthenticationRepository{

}
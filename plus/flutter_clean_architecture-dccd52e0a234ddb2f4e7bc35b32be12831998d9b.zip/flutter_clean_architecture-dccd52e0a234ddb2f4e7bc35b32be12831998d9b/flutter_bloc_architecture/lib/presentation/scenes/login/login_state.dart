import 'package:flutter_bloc_architecture/presentation/base/base_state.dart';

abstract class LoginState extends BaseState{}
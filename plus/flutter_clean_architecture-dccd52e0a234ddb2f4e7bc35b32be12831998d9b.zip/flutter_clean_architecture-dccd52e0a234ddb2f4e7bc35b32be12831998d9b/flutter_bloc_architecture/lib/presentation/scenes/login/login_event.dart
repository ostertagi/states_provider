import 'package:flutter_bloc_architecture/presentation/base/index.dart';

abstract class LoginEvent extends BaseEvent{}
import 'package:flutter_bloc_architecture/presentation/base/base_event.dart';

class AppEvent extends BaseEvent{}
abstract class BaseEvent{}

class PageInitStateEvent extends BaseEvent{}

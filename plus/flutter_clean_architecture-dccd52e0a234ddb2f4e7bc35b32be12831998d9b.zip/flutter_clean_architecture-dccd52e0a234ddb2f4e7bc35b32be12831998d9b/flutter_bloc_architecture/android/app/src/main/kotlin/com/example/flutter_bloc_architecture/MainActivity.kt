package com.example.flutter_bloc_architecture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

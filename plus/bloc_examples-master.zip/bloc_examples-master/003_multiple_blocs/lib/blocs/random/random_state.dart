part of 'random_bloc.dart';

class RandomState extends Equatable {
  final int random;
  const RandomState({this.random});

  @override
  // TODO: implement props
  List<Object> get props => [random];
}
